#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from nav_msgs.msg import  Odometry
from tf.transformations import euler_from_quaternion
from geometry_msgs.msg import Point
from math import atan2,sqrt,pow,pi
import time

x=0
y=0
theta=0

msg=Odometry()

def position(msg):
    global x
    global y
    global theta

    x=msg.pose.pose.position.x
    y=msg.pose.pose.position.y
    ora_q=msg.pose.pose.orientation
    (roll,pitch,theta)=euler_from_quaternion([ora_q.x,ora_q.y,ora_q.z,ora_q.w])

rospy.init_node('Speed_Controller')
sub=rospy.Subscriber('/odom',Odometry,callback=position)
pub=rospy.Publisher('/cmd_vel',Twist,queue_size=1)
rospy.sleep(0.3)
r=rospy.Rate(4)

#to set a goal
goal=Point()

goal.x= 6

goal.y= 6
speed=Twist()

while not rospy.is_shutdown():
    x_diff=goal.x-x
    y_diff=goal.y-y

    distance=sqrt(pow(y_diff,2)+pow(x_diff,2))
    angle_to_go=atan2(y_diff,x_diff)
    if abs(angle_to_go-theta)>0.1:
    

        speed.linear.x =0
        speed.angular.z=1.8 if (angle_to_go-theta)>0 else -0.7
        #ROTACION

    elif distance>0.1:
      

        speed=Twist()
        speed.linear.x =5.0
        speed.angular.z=0.0
 
    elif distance <= 0.1:
      
        t=Twist()
        pub.publish(t)
        print('\x1b[5;30;43m' + "--------------Enter New Coordinates--------------" + '\x1b[0m')
        t2 = time.time()


        goal.x = 0

        goal.y = 0
        
    pub.publish(speed)
    r.sleep()
